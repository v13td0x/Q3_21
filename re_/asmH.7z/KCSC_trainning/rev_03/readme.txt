makefile:
nasm -f elf bai3.asm && ld -m elf_i386 bai3.o -o bai3 && ./bai3
