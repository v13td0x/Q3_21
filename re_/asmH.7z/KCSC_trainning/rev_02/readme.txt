Makefile:
nasm -f elf bai2.asm
ld -m elf_i386 bai2.o -o bai2
./bai2
