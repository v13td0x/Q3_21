makefile:
nasm -f elf bai4.asm && ld -m elf_i386 bai4.o -o bai4 && ./bai4
