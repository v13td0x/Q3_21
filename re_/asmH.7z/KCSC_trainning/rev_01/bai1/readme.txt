makefile:
nasm -f elf bai1.asm
ld -m elf_i386 bai1.o -o bai1
./bai1
